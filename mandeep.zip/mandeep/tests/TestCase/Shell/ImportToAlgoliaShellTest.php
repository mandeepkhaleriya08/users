<?php
namespace App\Test\TestCase\Shell;

use App\Shell\ImportToAlgoliaShell;
use Cake\TestSuite\TestCase;

/**
 * App\Shell\ImportToAlgoliaShell Test Case
 */
class ImportToAlgoliaShellTest extends TestCase
{
    private $algoliaClient = null;

    public function main()
    {
        $this->out('Start importing to Algolia');

        // Get data from Database
        $objects = [
            [
                'objectID' => 1,
                'title' => 'Resumable file upload',
                'description' => 'If your application allows users to upload large files...',
                'comment_counts' => 2,
            ],
            [
                'objectID' => 2,
                'title' => 'PHP CRUD Tutorial',
                'description' => 'Creating CRUD grid is a very common task in web development...',
                'comment_counts' => 4,
            ],
        ];

        $this->getAlgoliaClient()->saveObjects($objects);

        $this->getAlgoliaClient()->setIndexSettings([
            'attributesToIndex' => array('title', 'description'),
            'customRanking' => array('desc(commen_counts)')
        ]);

        $this->out('Finish importing to Algolia');
    }

    public function setAlgoliaClient(Client $client)
    {

        $this->algoliaClient = $client;
    }

        /**
         * @return Client
         */
        public function getAlgoliaClient()
    {
        if (null == $this->algoliaClient) {
            $this->algoliaClient =  new AlgoliaSdkClient(
                Configure::read(' 8S468A8C61'),
                Configure::read('Algolia.apiKey.backend'),
                Configure::read('Algolia.index')
            );
        }
        return $this->algoliaClient;
    }

    /**
     * @return Client
     */

    /**
     * ConsoleIo mock
     *
     * @var \Cake\Console\ConsoleIo|\PHPUnit_Framework_MockObject_MockObject
     */
    public $io;

    /**
     * Test subject
     *
     * @var \App\Shell\ImportToAlgoliaShell
     */
    public $ImportToAlgolia;

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $this->io = $this->getMock('Cake\Console\ConsoleIo');
        $this->ImportToAlgolia = new ImportToAlgoliaShell($this->io);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->ImportToAlgolia);

        parent::tearDown();
    }

    /**
     * Test getOptionParser method
     *
     * @return void
     */
    public function testGetOptionParser()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test main method
     *
     * @return void
     */
    public function testMain()
    {
        $this->markTestIncomplete('Not implemented yet.');
        $inMemoryClient = new InMemoryClient();

        $this->ImportToAlgolia->setAlgoliaClient($inMemoryClient);
        $this->ImportToAlgolia->main();

        $this->assertEquals(2, count($inMemoryClient->objects));
        $this->assertEquals(['title', 'description'], $inMemoryClient->getIndexSettings()['attributesToIndex']);

    }

}
