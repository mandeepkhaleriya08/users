<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * FileUploads Controller
 *
 * @property \App\Model\Table\FileUploadsTable $FileUploads
 */
class FileUploadsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $fileUploads = $this->paginate($this->FileUploads);

        $this->set(compact('fileUploads'));
        $this->set('_serialize', ['fileUploads']);
    }

    /**
     * View method
     *
     * @param string|null $id File Upload id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $fileUpload = $this->FileUploads->get($id, [
            'contain' => []
        ]);

        $this->set('fileUpload', $fileUpload);
        $this->set('_serialize', ['fileUpload']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
   /* public function add()
    {
        $fileUpload = $this->FileUploads->newEntity();
        if ($this->request->is('post')) {
            $fileUpload = $this->FileUploads->patchEntity($fileUpload, $this->request->data);
            if ($this->FileUploads->save($fileUpload)) {
                $this->Flash->success(__('The file upload has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The file upload could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('fileUpload'));
        $this->set('_serialize', ['fileUpload']);
    }*/
    function add() {
        if (!empty($this->data)) {
            $this->FileUploads->create();
            if ($this->FileUpload() && $this->FileUploads->save($this->data))  {
                $this->Session->setFlash(__('The upload has been saved', true));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The upload could not be saved. Please, try again.', true));
            }
        }
    }
    function uploadFile() {
        $file = $this->data[‘Upload’][‘file’];
  if ($file[‘error’] === UPLOAD_ERR_OK) {
            $id = String::uuid();
            if (move_uploaded_file($file[‘tmp_name’], APP.’webroot/uploads’.DS.$id)) {
                $this->data[‘Upload’][‘id’] = $id;
      $this->data[‘Upload’][‘filename’] = $file[‘name’];
      $this->data[‘Upload’][‘filesize’] = $file[‘size’];
      $this->data[‘Upload’][‘filemime’] = $file[‘type’];
      return true;
    }
  }
  return false;
}

    /**
     * Edit method
     *
     * @param string|null $id File Upload id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $fileUpload = $this->FileUploads->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $fileUpload = $this->FileUploads->patchEntity($fileUpload, $this->request->data);
            if ($this->FileUploads->save($fileUpload)) {
                $this->Flash->success(__('The file upload has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The file upload could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('fileUpload'));
        $this->set('_serialize', ['fileUpload']);
    }

    /**
     * Delete method
     *
     * @param string|null $id File Upload id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $fileUpload = $this->FileUploads->get($id);
        if ($this->FileUploads->delete($fileUpload)) {
            $this->Flash->success(__('The file upload has been deleted.'));
        } else {
            $this->Flash->error(__('The file upload could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
