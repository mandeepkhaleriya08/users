<?php
namespace App\Controller;


class SearchesController extends AppController
{

    public function index()
    {

    }
}
