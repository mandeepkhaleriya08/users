<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Reports Controller
 *
 * @property \App\Model\Table\ReportsTable $Reports
 */
class ReportsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $reports = $this->paginate($this->Reports);

        $this->set(compact('reports'));
        $this->set('_serialize', ['reports']);
    }

    /**
     * View method
     *
     * @param string|null $id Report id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $report = $this->Reports->get($id, [
            'contain' => []
        ]);

        $this->set('report', $report);
        $this->set('_serialize', ['report']);
    }


    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    /*public function add()
    {
        if ($this->request->is('post')) {
            //$this->Report->create();
            if (empty($this->data['Report']['report']['name'])) {
                unset($this->request->data['Report']['report']);
            }
            if (!empty($this->data['Report']['report']['name'])) {
                $file = $this->data['Report']['report'];
                $file['name'] = $this->sanitize($file['name']);
                $this->request->data['Report']['report'] = time() . $file['name'];

                if ($this->Report->save($this->request->data)) {
                    move_uploaded_file($file['tmp_name'], WWW_ROOT . 'outsidefiles' . DS . time() . $file['name']);
                    $this->Flash->success(__('Your Report has been saved.'));
                    return $this->redirect(array('action' => 'index'));
                }
            }
            $this->Flash->error(__('Unable to add your Report.'));
        }
    }*/
   /* public function add()
    {
        $report = $this->Reports->newEntity();
        if ($this->request->is('post')) {

            if (empty($this->data['Report']['report']['name'])) {
                unset($this->request->data['Report']['report']);
            }
            if (!empty($this->data['Report']['report']['name'])) {
                $report = $this->data['Report']['report'];
                $report['name'] = $this->sanitize($report['name']);
                $this->request->data['Report']['report'] = time() . $report['name'];
                //$report = $this->Reports->patchEntity($report, $this->request->data);
                if ($this->Reports->save($report)) {
                    move_uploaded_file($file['tmp_name'], WWW_ROOT . 'outsidefiles' . DS . time() . $file['name']);
                    $this->Flash->success(__('The report has been saved.'));
                    return $this->redirect(['action' => 'index']);
                } else {
                    $this->Flash->error(__('The report could not be saved. Please, try again.'));
                }
            }
            $this->set(compact('report'));
            $this->set('_serialize', ['report']);
        }
    }*/

    public function add()
    {
        $uploadData = '';
        if ($this->request->is('post')) {
            if (!empty($this->request->data['Report']['report']['name'])) {
                $fileName = $this->request->data['Report']['report'];
                $uploadPath = 'outsidefiles';
                $uploadFile = $uploadPath . $fileName;
                if (move_uploaded_file($this->request->data['report']['tmp_name'], $uploadFile)) {
                    $uploadData = $this->Reports->newEntity();
                    $uploadData->name = $fileName;
                    $uploadData->path = $uploadPath;
                    $uploadData->created = date("Y-m-d H:i:s");
                    $uploadData->modified = date("Y-m-d H:i:s");
                    if ($this->Reports->save($uploadData)) {
                        $this->Reports->success(__('File has been uploaded and inserted successfully.'));
                    } else {
                        $this->Flash->error(__('Unable to upload file, please try again.'));
                    }
                } else {
                    $this->Flash->error(__('Unable to upload file, please try again.'));
                }
            } else {
                $this->Flash->error(__('Please choose a file to upload.'));
            }

        }
        $this->set('uploadData', $uploadData);

        $files = $this->Reports->find('all', ['order' => ['Reports.created' => 'DESC']]);
        $filesRowNum = $files->count();
        $this->set('report', $files);
        $this->set('filesRowNum', $filesRowNum);
    }

    /**
     * Edit method
     *
     * @param string|null $id Report id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $report = $this->Reports->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $report = $this->Reports->patchEntity($report, $this->request->data);
            if ($this->Reports->save($report)) {
                $this->Flash->success(__('The report has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The report could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('report'));
        $this->set('_serialize', ['report']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Report id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $report = $this->Reports->get($id);
        if ($this->Reports->delete($report)) {
            $this->Flash->success(__('The report has been deleted.'));
        } else {
            $this->Flash->error(__('The report could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
    function sanitize($string, $force_lowercase = true, $anal = false) {
        $strip = array("~", "`", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "=", "+", "[", "{", "]","}", "\\", "|", ";", ":", "\"", "'", "&#8216;", "&#8217;", "&#8220;", "&#8221;", "&#8211;", "&#8212;","â€”", "â€“", ",", "<",">", "/", "?");
        $clean = trim(str_replace($strip, "", strip_tags($string)));
        $clean = preg_replace('/\s+/', "-", $clean);
        $clean = ($anal) ? preg_replace("/[^a-zA-Z0-9]/", "", $clean) : $clean ;
        return ($force_lowercase) ?
            (function_exists('mb_strtolower')) ?
                mb_strtolower($clean, 'UTF-8') :
                strtolower($clean) :
            $clean;
    }

    public function viewdown($id=null,$download=false) {
        if($download){
            $download=true;
        }
        $report = $this->Reports->get($id, [
            'contain' => []
        ]);
       // $files=$this->Report->get($id);
        $filename=$report['Report']['report'];
        $name=explode('.',$filename);
        $this->viewClass = 'Media';

        // path will be app/outsidefiles/yourfilename.pdf
        $params = array(
            'id'        => $filename,
            'name'      => $name[0],
            'download'  => $download,
            'extension' => 'pdf','jpeg','jpg','mpeg','png','gif','zip','rar',
            'path'      => WWW_ROOT. 'outsidefiles' . DS
        );

        $this->set($params);
    }
}
