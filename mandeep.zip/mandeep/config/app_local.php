<?php

return [
    'Algolia' => [
        'appId' => 'A388CTBZWA',
        'apiKey' => [
            'backend' => '00e5f1fa24276da528c10d633729d3fe',
            'search' => '204a6848b78ea7c3cc97702cd8a9869a',
        ],
        'index' => 'tutorial',
    ]
];
?>